class LinearVAE(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  encoders : __torch__.torch.nn.modules.container.ModuleList
  enc_mu : __torch__.torch.nn.modules.linear.___torch_mangle_1.Linear
  enc_log_var : __torch__.torch.nn.modules.linear.___torch_mangle_2.Linear
  decoders : __torch__.torch.nn.modules.container.___torch_mangle_6.ModuleList
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  def forward(self: __torch__.models.LinearVAE,
    z: Tensor) -> Tensor:
    decoders = self.decoders
    _2 = getattr(decoders, "2")
    decoders0 = self.decoders
    _1 = getattr(decoders0, "1")
    dropout = self.dropout
    decoders1 = self.decoders
    _0 = getattr(decoders1, "0")
    input = torch.relu((_0).forward(z, ))
    _3 = (_1).forward((dropout).forward(input, ), )
    input0 = torch.relu(_3)
    _4 = (_2).forward((dropout).forward1(input0, ), )
    return _4
