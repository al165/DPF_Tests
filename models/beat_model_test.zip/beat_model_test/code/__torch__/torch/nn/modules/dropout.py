class Dropout(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.dropout.Dropout,
    input: Tensor) -> Tensor:
    input0 = torch.dropout(input, 0.29999999999999999, False)
    return input0
  def forward1(self: __torch__.torch.nn.modules.dropout.Dropout,
    input: Tensor) -> Tensor:
    input1 = torch.dropout(input, 0.29999999999999999, False)
    return input1
